require('dotenv').config();

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');

const authRoutes = require('./routes/auth');
const examRoutes = require('./routes/exams');
const qbRoutes = require('./routes/questionbank');
const paperRoutes = require('./routes/papers');
const markRoutes = require('./routes/marks');
const hallRoutes = require('./routes/hallticket');
const analyticsRoutes = require('./routes/analytics');

const app = express();

// Middleware
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname,'uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/exams', examRoutes);
app.use('/api/questionbank', qbRoutes);
app.use('/api/papers', paperRoutes);
app.use('/api/marks', markRoutes);
app.use('/api/hallticket', hallRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/academics', require('./routes/academics'));
app.use('/api/students', require('./routes/students'));
app.use('/api/assessments', require('./routes/assessments'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/halltickets', require('./routes/halltickets'));
app.use('/api/evaluation', require('./routes/evaluation'));


// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'OK', message: 'ECMS Backend is running' });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

const PORT = process.env.PORT || 5000;

mongoose.connect(process.env.MONGO_URI, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
})
.then(()=> {
  console.log('MongoDB connected successfully');
  app.listen(PORT, ()=> console.log(`Server running on port ${PORT}`));
})
.catch(err => {
  console.error('MongoDB connection error:', err);
  process.exit(1);
});
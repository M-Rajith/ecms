require('dotenv').config();

const mongoose = require('mongoose');
const Student = require('./models/Student');
const User = require('./models/User');
const Exam = require('./models/Exam');
const Question = require('./models/Question');
const bcrypt = require('bcryptjs');

mongoose.connect(process.env.MONGO_URI).then(async ()=>{
  console.log('Connected to MongoDB for seeding');

  // Clear existing data
  await Student.deleteMany({});
  await User.deleteMany({});
  await Exam.deleteMany({});
  await Question.deleteMany({});

  // Insert sample students
  await Student.insertMany([
    { studentId: 'S1001', name: 'Ravi Kumar', program: 'BTech', year: 3, department: 'CSE' },
    { studentId: 'S1002', name: 'Priya Sharma', program: 'BTech', year: 3, department: 'CSE' },
    { studentId: 'S1003', name: 'Aishwarya', program: 'BTech', year: 2, department: 'ECE' },
    { studentId: 'S1004', name: 'Rohit Singh', program: 'BTech', year: 4, department: 'ME' },
    { studentId: 'S1005', name: 'Anjali Patel', program: 'BTech', year: 1, department: 'CSE' }
  ]);

  // Create default users
  const pw = await bcrypt.hash('password', 8);
  await User.create({ name: 'Coordinator', email: 'coe@example.com', passwordHash: pw, role: 'coordinator' });
  await User.create({ name: 'Prof Smith', email: 'faculty@example.com', passwordHash: pw, role: 'faculty' });
  await User.create({ name: 'Student User', email: 'student@example.com', passwordHash: pw, role: 'student', studentId: 'S1001' });

  // Create sample exams
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);

  await Exam.create({
    title: 'Operating Systems - Final',
    code: 'CS301F',
    date: tomorrow,
    startTime: '12:33',
    endTime: '15:33',
    type: 'Final',
    course: 'Operating Systems',
    rooms: ['Room A', 'Room B']
  });

  await Exam.create({
    title: 'Database Systems - Midterm',
    code: 'CS302M',
    date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
    startTime: '10:00',
    endTime: '12:00',
    type: 'Midterm',
    course: 'Database Systems',
    rooms: ['Room C']
  });

  // Create sample questions
  await Question.insertMany([
    { text: 'Explain process synchronization', subject: 'Operating Systems', marks: 10, difficulty: 'Medium' },
    { text: 'What is a deadlock?', subject: 'Operating Systems', marks: 5, difficulty: 'Easy' },
    { text: 'Describe normalization in databases', subject: 'Database Systems', marks: 15, difficulty: 'Hard' },
    { text: 'What is SQL?', subject: 'Database Systems', marks: 3, difficulty: 'Easy' }
  ]);

  console.log('Sample data seeded successfully');
  process.exit(0);
}).catch(err => {
  console.error('Seeding error:', err);
  process.exit(1);
});
const express = require('express');
const router = express.Router();
const EvaluationBundle = require('../models/EvaluationBundle');
const auth = require('../middleware');

// Create a bundle (max 25 scripts)
router.post('/', auth, async (req, res) => {
  if (!['coordinator','hod'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Access denied' });
  }
  const { subject, exam, scripts } = req.body;
  if (scripts.length > 25) return res.status(400).json({ error: "Max 25 scripts per bundle" });
  const bundle = new EvaluationBundle({ subject, exam, scripts, evaluator: req.user.id });
  await bundle.save();
  res.json(bundle);
});

// Get bundle summaries
router.get('/summary/:examId', auth, async (req, res) => {
  const bundles = await EvaluationBundle.find({ exam: req.params.examId });
  res.json(bundles.map(bundle => ({
    bundleNumber: bundle.bundleNumber,
    subject: bundle.subject,
    scripts: bundle.scripts.map(s => ({
      student: s.student,
      status: s.status,
      isEvaluated: s.isEvaluated
    }))
  })));
});
module.exports = router;

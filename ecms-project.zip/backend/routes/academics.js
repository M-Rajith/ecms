const express = require('express');
const router = express.Router();
const AcademicYear = require('../models/AcademicYear');
const Department = require('../models/Department');
const Curriculum = require('../models/Curriculum');
const auth = require('../middleware');

// Get all academic years
router.get('/years', auth, async (req, res) => {
  try {
    const years = await AcademicYear.find().sort({ year: -1 });
    res.json(years);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create academic year (CoE only)
router.post('/years', auth, async (req, res) => {
  try {
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only CoE can create academic years' });
    }

    const academicYear = new AcademicYear(req.body);
    await academicYear.save();
    res.status(201).json(academicYear);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get all departments
router.get('/departments', auth, async (req, res) => {
  try {
    const departments = await Department.find().populate('hod', 'name email');
    res.json(departments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create department (CoE only)
router.post('/departments', auth, async (req, res) => {
  try {
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only CoE can create departments' });
    }

    const department = new Department(req.body);
    await department.save();
    res.status(201).json(department);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get curriculum by department and batch
router.get('/curriculum/:departmentId/:batch', auth, async (req, res) => {
  try {
    const curriculum = await Curriculum.findOne({
      department: req.params.departmentId,
      batch: req.params.batch
    }).populate('department', 'name code');
    
    if (!curriculum) {
      return res.status(404).json({ error: 'Curriculum not found' });
    }
    
    res.json(curriculum);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create/Update curriculum (CoE/HoD only)
router.post('/curriculum', auth, async (req, res) => {
  try {
    if (!['coordinator', 'hod'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Only CoE or HoD can manage curriculum' });
    }

    const { department, batch } = req.body;
    
    let curriculum = await Curriculum.findOne({ department, batch });
    
    if (curriculum) {
      curriculum = await Curriculum.findByIdAndUpdate(curriculum._id, req.body, { new: true });
    } else {
      curriculum = new Curriculum(req.body);
      await curriculum.save();
    }
    
    res.json(curriculum);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;

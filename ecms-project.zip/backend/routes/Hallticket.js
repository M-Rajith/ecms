const express = require('express');
const router = express.Router();
const Exam = require('../models/Exam');
const Student = require('../models/Student');
const QRCode = require('qrcode');
const auth = require('../middleware');

router.get('/:examId/student/:studentId', auth, async (req,res)=>{
  try {
    const exam = await Exam.findById(req.params.examId);
    const student = await Student.findOne({ studentId: req.params.studentId });

    if(!exam || !student) {
      return res.status(404).json({ error: 'Exam or student not found' });
    }

    const payload = {
      examId: exam._id,
      examTitle: exam.title,
      studentId: student.studentId,
      name: student.name,
      date: exam.date,
      startTime: exam.startTime,
      endTime: exam.endTime,
      course: exam.course
    };

    const qrData = JSON.stringify(payload);
    const dataUrl = await QRCode.toDataURL(qrData);

    res.json({ 
      hallticket: { 
        student, 
        exam, 
        qr: dataUrl,
        generatedAt: new Date()
      } 
    });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
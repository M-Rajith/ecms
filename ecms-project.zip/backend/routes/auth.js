const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

router.post('/register', async (req,res)=> {
  try {
    const { name, email, password, role, studentId } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required' });
    }

    const hash = await bcrypt.hash(password, 10);
    const u = new User({ name, email, passwordHash: hash, role, studentId });
    await u.save();

    res.json({ ok: true, message: 'User registered successfully' });
  } catch(e) { 
    res.status(400).json({ error: e.message}); 
  }
});

router.post('/login', async (req,res)=> {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = await User.findOne({ email });
    if(!user) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if(!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ 
      id: user._id, 
      role: user.role, 
      name: user.name, 
      studentId: user.studentId 
    }, process.env.JWT_SECRET, { expiresIn: '24h' });

    res.json({ token, role: user.role, name: user.name });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/me', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token provided' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-passwordHash');

    res.json(user);
  } catch(error) {
    res.status(401).json({ error: 'Invalid token' });
  }
});

module.exports = router;
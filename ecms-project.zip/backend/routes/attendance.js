const express = require('express');
const router = express.Router();
const ExamAttendance = require('../models/ExamAttendance');
const auth = require('../middleware');

// Get attendance for exam
router.get('/exam/:examId', auth, async (req, res) => {
  const attendanceList = await ExamAttendance.find({ exam: req.params.examId })
    .populate('student', 'studentId name');
  res.json(attendanceList);
});

// Mark/Update attendance (Faculty/Coordinator)
router.post('/', auth, async (req, res) => {
  if (!['faculty', 'coordinator'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Not authorized' });
  }
  const { exam, student, status } = req.body;
  let attendance = await ExamAttendance.findOne({ exam, student });
  if (!attendance) {
    attendance = new ExamAttendance({
      exam,
      student,
      attendanceStatus: status,
      invigilator: req.user.id
    });
  } else {
    attendance.attendanceStatus = status;
    attendance.invigilator = req.user.id;
  }
  await attendance.save();
  res.json(attendance);
});

// Finalize attendance (Faculty) / Override (Coordinator)
router.put('/:id/finalize', auth, async (req, res) => {
  const attendance = await ExamAttendance.findById(req.params.id);
  if (!attendance) return res.status(404).json({ error: 'Not found' });
  if (req.user.role === 'faculty' && attendance.invigilator.toString() !== req.user.id)
    return res.status(403).json({ error: 'Only assigned invigilator can finalize' });
  attendance.isFinalized = true;
  attendance.finalizedBy = req.user.id;
  attendance.finalizedAt = new Date();
  await attendance.save();
  res.json({ message: 'Attendance finalized', attendance });
});

module.exports = router;

const express = require('express');
const router = express.Router();
const Question = require('../models/Question');
const auth = require('../middleware');

router.post('/', auth, async (req,res)=>{
  try {
    if(req.user.role === 'student') {
      return res.status(403).json({ error: 'Students cannot create questions' });
    }

    const { text, subject, marks, difficulty } = req.body;

    if (!text || !subject || !marks) {
      return res.status(400).json({ error: 'Question text, subject, and marks are required' });
    }

    const question = new Question({ 
      text, subject, marks, difficulty: difficulty || 'Medium', 
      createdBy: req.user.id 
    });

    await question.save();
    res.json(question);
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/', auth, async (req,res)=>{
  try {
    const { subject, difficulty } = req.query;
    let filter = {};

    if (subject) filter.subject = subject;
    if (difficulty) filter.difficulty = difficulty;

    const questions = await Question.find(filter)
      .populate('createdBy', 'name')
      .sort({ subject: 1, difficulty: 1 });

    res.json(questions);
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const EnhancedStudent = require('../models/EnhancedStudent');
const Assessment = require('../models/Assessment');
const auth = require('../middleware');

// Get all students with filters
router.get('/', auth, async (req, res) => {
  try {
    const { department, batch, semester, status } = req.query;
    let filter = {};
    
    if (department) filter.department = department;
    if (batch) filter.batch = batch;
    if (semester) filter.currentSemester = semester;
    if (status) filter.status = status;

    const students = await EnhancedStudent.find(filter)
      .populate('department', 'name code')
      .sort({ studentId: 1 });
    
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get student profile with complete history
router.get('/:studentId/profile', auth, async (req, res) => {
  try {
    const student = await EnhancedStudent.findOne({ studentId: req.params.studentId })
      .populate('department', 'name code');
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // Get all assessments
    const assessments = await Assessment.find({ student: student._id })
      .populate('enteredBy finalizedBy', 'name')
      .sort({ semester: 1, createdAt: -1 });

    // Calculate semester-wise results
    const semesterResults = {};
    assessments.forEach(assessment => {
      const key = `${assessment.semester}-${assessment.academicYear}`;
      if (!semesterResults[key]) {
        semesterResults[key] = {
          semester: assessment.semester,
          academicYear: assessment.academicYear,
          subjects: {}
        };
      }
      
      const subjectKey = assessment.subject;
      if (!semesterResults[key].subjects[subjectKey]) {
        semesterResults[key].subjects[subjectKey] = {
          subject: assessment.subject,
          internal: null,
          external: null,
          practical: null,
          total: 0,
          grade: '',
          status: 'Pending'
        };
      }
      
      semesterResults[key].subjects[subjectKey][assessment.assessmentType.toLowerCase()] = assessment.marks;
    });

    res.json({
      student,
      assessments,
      semesterResults: Object.values(semesterResults),
      malpracticeCount: student.malpracticeRecords.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add malpractice record (CoE/Invigilator)
router.post('/:studentId/malpractice', auth, async (req, res) => {
  try {
    if (!['coordinator', 'faculty'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }

    const student = await EnhancedStudent.findOne({ studentId: req.params.studentId });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const malpracticeRecord = {
      ...req.body,
      reportedBy: req.user.id,
      date: new Date()
    };

    student.malpracticeRecords.push(malpracticeRecord);
    await student.save();

    res.json({ message: 'Malpractice record added successfully', student });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update fee status (CoE only)
router.put('/:studentId/fees', auth, async (req, res) => {
  try {
    if (req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only CoE can update fee status' });
    }

    const { semester, academicYear, isPaid, amount } = req.body;
    
    const student = await EnhancedStudent.findOne({ studentId: req.params.studentId });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const feeRecord = student.feeStatus.find(
      fee => fee.semester === semester && fee.academicYear === academicYear
    );

    if (feeRecord) {
      feeRecord.isPaid = isPaid;
      feeRecord.amount = amount;
      if (isPaid) feeRecord.paidDate = new Date();
    } else {
      student.feeStatus.push({
        semester,
        academicYear,
        isPaid,
        amount,
        paidDate: isPaid ? new Date() : null
      });
    }

    await student.save();
    res.json({ message: 'Fee status updated successfully', student });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;

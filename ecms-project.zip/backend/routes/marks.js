const express = require('express');
const router = express.Router();
const Mark = require('../models/Mark');
const Student = require('../models/Student');
const auth = require('../middleware');

router.post('/enter', auth, async (req,res)=>{
  try {
    if(req.user.role === 'student') {
      return res.status(403).json({ error: 'Students cannot enter marks' });
    }

    const { examId, studentId, marks, totalMarks } = req.body;

    if (!examId || !studentId || marks === undefined) {
      return res.status(400).json({ error: 'Exam ID, student ID, and marks are required' });
    }

    const student = await Student.findOne({ studentId });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    let mark = await Mark.findOne({ exam: examId, student: student._id });

    if(!mark) {
      mark = new Mark({ 
        exam: examId, 
        student: student._id, 
        marks, 
        totalMarks: totalMarks || 100,
        gradedBy: req.user.id
      });
    } else { 
      mark.marks = marks;
      mark.totalMarks = totalMarks || mark.totalMarks;
      mark.gradedBy = req.user.id; 
    }

    // Calculate grade
    const percentage = (marks / mark.totalMarks) * 100;
    if (percentage >= 90) mark.grade = 'A+';
    else if (percentage >= 80) mark.grade = 'A';
    else if (percentage >= 70) mark.grade = 'B+';
    else if (percentage >= 60) mark.grade = 'B';
    else if (percentage >= 50) mark.grade = 'C';
    else mark.grade = 'F';

    await mark.save();
    await mark.populate('student', 'studentId name department');

    res.json(mark);
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/exam/:id/results', auth, async (req,res)=>{
  try {
    const marks = await Mark.find({ exam: req.params.id })
      .populate('student', 'studentId name department')
      .sort({ marks: -1 });

    const stats = {
      totalStudents: marks.length,
      averageMarks: marks.reduce((sum, m) => sum + m.marks, 0) / marks.length || 0,
      highestMarks: Math.max(...marks.map(m => m.marks), 0),
      lowestMarks: Math.min(...marks.map(m => m.marks), 0),
      passedStudents: marks.filter(m => m.grade !== 'F').length
    };

    res.json({ marks, stats });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
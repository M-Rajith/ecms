const express = require('express');
const router = express.Router();
const Paper = require('../models/Paper');
const Question = require('../models/Question');
const auth = require('../middleware');

router.post('/generate', auth, async (req,res)=>{
  try {
    if(req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only coordinators can generate papers' });
    }

    const { examId, numQuestions, subject } = req.body;

    if (!examId || !numQuestions) {
      return res.status(400).json({ error: 'Exam ID and number of questions are required' });
    }

    let filter = {};
    if (subject) filter.subject = subject;

    const questions = await Question.aggregate([
      { $match: filter },
      { $sample: { size: Number(numQuestions) } }
    ]);

    if (questions.length < numQuestions) {
      return res.status(400).json({ 
        error: `Only ${questions.length} questions available, requested ${numQuestions}` 
      });
    }

    const qIds = questions.map(q => q._id);
    const paper = new Paper({ 
      exam: examId, 
      questions: qIds, 
      generatedAt: new Date(), 
      createdBy: req.user.id 
    });

    await paper.save();

    res.json({ 
      paper, 
      questions,
      totalMarks: questions.reduce((sum, q) => sum + q.marks, 0),
      message: 'Exam paper generated successfully' 
    });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
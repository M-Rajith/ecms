const express = require('express');
const router = express.Router();
const Exam = require('../models/Exam');
const Mark = require('../models/Mark');
const Student = require('../models/Student');
const Question = require('../models/Question');
const auth = require('../middleware');

router.get('/dashboard', auth, async (req,res)=>{
  try {
    const totalExams = await Exam.countDocuments();
    const totalStudents = await Student.countDocuments();
    const totalQuestions = await Question.countDocuments();
    const totalMarks = await Mark.countDocuments();

    const upcomingExams = await Exam.find({ 
      date: { $gte: new Date() } 
    }).limit(5).sort({ date: 1 });

    const recentResults = await Mark.find()
      .populate('student', 'name studentId')
      .populate('exam', 'title')
      .limit(10)
      .sort({ createdAt: -1 });

    res.json({
      overview: {
        totalExams,
        totalStudents,
        totalQuestions,
        totalMarks
      },
      upcomingExams,
      recentResults
    });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
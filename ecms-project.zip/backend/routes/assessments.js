const express = require('express');
const router = express.Router();
const Assessment = require('../models/Assessment');
const EnhancedStudent = require('../models/EnhancedStudent');
const auth = require('../middleware');

// Get assessments with filters
router.get('/', auth, async (req, res) => {
  try {
    const { semester, subject, assessmentType, isFinalized } = req.query;
    let filter = {};
    
    if (semester) filter.semester = semester;
    if (subject) filter.subject = subject;
    if (assessmentType) filter.assessmentType = assessmentType;
    if (isFinalized !== undefined) filter.isFinalized = isFinalized === 'true';

    // Faculty can only see their own entries (unless CoE)
    if (req.user.role === 'faculty') {
      filter.enteredBy = req.user.id;
    }

    const assessments = await Assessment.find(filter)
      .populate('student', 'studentId name')
      .populate('enteredBy finalizedBy', 'name')
      .sort({ createdAt: -1 });

    res.json(assessments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create/Update assessment
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role === 'student') {
      return res.status(403).json({ error: 'Students cannot enter marks' });
    }

    const { studentId, assessmentType } = req.body;
    
    // Only CoE can enter external marks
    if (assessmentType === 'External' && req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only CoE can enter external marks' });
    }

    const student = await EnhancedStudent.findOne({ studentId });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    let assessment = await Assessment.findOne({
      student: student._id,
      subject: req.body.subject,
      semester: req.body.semester,
      assessmentType: assessmentType
    });

    if (assessment) {
      // Check if finalized and user is not CoE
      if (assessment.isFinalized && req.user.role !== 'coordinator') {
        return res.status(403).json({ error: 'Cannot modify finalized assessment. Contact CoE for changes.' });
      }
      
      assessment = await Assessment.findByIdAndUpdate(
        assessment._id,
        { ...req.body, student: student._id, lastModifiedBy: req.user.id },
        { new: true }
      );
    } else {
      assessment = new Assessment({
        ...req.body,
        student: student._id,
        enteredBy: req.user.id
      });
      await assessment.save();
    }

    await assessment.populate('student', 'studentId name');
    res.json(assessment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Finalize assessment (Faculty/CoE)
router.put('/:id/finalize', auth, async (req, res) => {
  try {
    const assessment = await Assessment.findById(req.params.id);
    if (!assessment) {
      return res.status(404).json({ error: 'Assessment not found' });
    }

    // Faculty can only finalize their own entries
    if (req.user.role === 'faculty' && assessment.enteredBy.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Can only finalize your own entries' });
    }

    assessment.isFinalized = true;
    assessment.finalizedBy = req.user.id;
    assessment.finalizedAt = new Date();
    await assessment.save();

    await assessment.populate('student finalizedBy', 'studentId name');
    res.json({ message: 'Assessment finalized successfully', assessment });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get arrear subjects for student
router.get('/arrears/:studentId', auth, async (req, res) => {
  try {
    const student = await EnhancedStudent.findOne({ studentId: req.params.studentId });
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    // Find failed subjects
    const assessments = await Assessment.find({ 
      student: student._id,
      'marks.grade': { $in: ['F', 'Ab'] }
    }).populate('student', 'studentId name');

    // Get original internal marks for arrear subjects
    const arrearSubjects = [];
    for (const assessment of assessments) {
      if (assessment.assessmentType === 'External') {
        const internalAssessment = await Assessment.findOne({
          student: student._id,
          subject: assessment.subject,
          semester: assessment.semester,
          assessmentType: 'Internal'
        });

        arrearSubjects.push({
          subject: assessment.subject,
          semester: assessment.semester,
          originalInternal: internalAssessment ? internalAssessment.marks : null,
          originalExternal: assessment.marks,
          examType: 'Arrear'
        });
      }
    }

    res.json(arrearSubjects);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

const express = require('express');
const router = express.Router();
const Exam = require('../models/Exam');
const Student = require('../models/Student');
const auth = require('../middleware');

router.post('/', auth, async (req,res)=>{
  try {
    if(req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only coordinators can create exams' });
    }

    const { title, code, date, startTime, endTime, course, rooms } = req.body;

    if (!title || !code || !date || !startTime || !endTime || !course) {
      return res.status(400).json({ error: 'All exam details are required' });
    }

    const exam = new Exam({ 
      title, code, date, startTime, endTime, course, rooms: rooms || [], 
      createdBy: req.user.id 
    });

    await exam.save();
    res.json(exam);
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/', auth, async (req,res)=>{
  try {
    const exams = await Exam.find()
      .populate('createdBy', 'name')
      .sort({ date: 1 });
    res.json(exams);
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/:id/generate-seating', auth, async (req,res)=>{
  try {
    if(req.user.role !== 'coordinator') {
      return res.status(403).json({ error: 'Only coordinators can generate seating' });
    }

    const exam = await Exam.findById(req.params.id);
    if(!exam) return res.status(404).json({ error: 'Exam not found' });

    const students = await Student.find();
    if (students.length === 0) {
      return res.status(400).json({ error: 'No students found for seating arrangement' });
    }

    let seating = [];
    let roomIndex = 0, seatNo = 1;
    const roomCapacity = 30;

    for(const student of students){
      const roomName = exam.rooms[roomIndex] || `Room-${roomIndex + 1}`;
      const seat = `${roomName}-R${seatNo}`;

      seating.push({ 
        studentId: student.studentId, 
        seat, 
        name: student.name,
        department: student.department
      });

      seatNo++;
      if(seatNo > roomCapacity) { 
        roomIndex++; 
        seatNo = 1; 
      }
    }

    exam.seatingGenerated = true;
    await exam.save();

    res.json({ 
      seating, 
      totalStudents: students.length,
      roomsUsed: Math.ceil(students.length / roomCapacity),
      message: 'Seating arrangement generated successfully' 
    });
  } catch(error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
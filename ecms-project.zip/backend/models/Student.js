const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  studentId: { type: String, unique: true },
  name: String,
  program: String,
  year: Number,
  department: String
}, { timestamps: true });

module.exports = mongoose.model('Student', studentSchema);

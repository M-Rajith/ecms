const mongoose = require('mongoose');

const evaluationBundleSchema = new mongoose.Schema({
  bundleNumber: { type: String, unique: true },
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam' },
  subject: String,
  evaluator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  scripts: [{
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'EnhancedStudent' },
    hallTicketNumber: String,
    status: { type: String, enum: ['Present', 'Absent', 'Malpractice'] },
    marks: Number,
    isEvaluated: { type: Boolean, default: false }
  }],
  maxScripts: { type: Number, default: 25 },
  isCompleted: { type: Boolean, default: false },
  completedAt: Date
}, { timestamps: true });

module.exports = mongoose.model('EvaluationBundle', evaluationBundleSchema);

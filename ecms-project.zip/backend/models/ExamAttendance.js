const mongoose = require('mongoose');

const examAttendanceSchema = new mongoose.Schema({
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam', required: true },
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'EnhancedStudent', required: true },
  subject: String,
  attendanceStatus: { 
    type: String, 
    enum: ['Present', 'Absent', 'Malpractice'], 
    default: 'Absent' 
  },
  hallTicketNumber: String,
  seatNumber: String,
  hall: String,
  invigilator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isFinalized: { type: Boolean, default: false },
  finalizedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  finalizedAt: Date,
  remarks: String
}, { timestamps: true });

module.exports = mongoose.model('ExamAttendance', examAttendanceSchema);

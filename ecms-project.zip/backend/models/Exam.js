const mongoose = require('mongoose');

const examSchema = new mongoose.Schema({
  title: String,
  code: String,
  date: Date,
  startTime: String,
  endTime: String,
  type: { type: String, default: 'Final' },
  course: String,
  rooms: [String],
  seatingGenerated: { type: Boolean, default: false },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('Exam', examSchema);
const mongoose = require('mongoose');

const academicYearSchema = new mongoose.Schema({
  year: { type: String, required: true, unique: true }, // e.g., "2021-2022"
  startDate: Date,
  endDate: Date,
  isActive: { type: Boolean, default: false },
  semesters: [{
    semesterNumber: Number,
    startDate: Date,
    endDate: Date,
    examStartDate: Date,
    examEndDate: Date
  }]
}, { timestamps: true });

module.exports = mongoose.model('AcademicYear', academicYearSchema);

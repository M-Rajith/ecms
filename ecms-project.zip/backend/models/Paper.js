const mongoose = require('mongoose');

const paperSchema = new mongoose.Schema({
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam' },
  questions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Question' }],
  generatedAt: Date,
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  notes: String
}, { timestamps: true });

module.exports = mongoose.model('Paper', paperSchema);
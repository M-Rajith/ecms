const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true }, // e.g., "CSE"
  name: { type: String, required: true }, // e.g., "Computer Science Engineering"
  hod: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  programs: [{
    name: String, // e.g., "B.Tech", "M.Tech"
    duration: Number, // in years
    totalSemesters: Number
  }]
}, { timestamps: true });

module.exports = mongoose.model('Department', departmentSchema);

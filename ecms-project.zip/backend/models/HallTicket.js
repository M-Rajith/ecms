const mongoose = require('mongoose');

const hallTicketSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'EnhancedStudent', required: true },
  ticketNumber: { type: String, unique: true },
  semester: Number,
  academicYear: String,
  examType: { type: String, enum: ['Regular', 'Supplementary', 'Arrear'] },
  subjects: [{
    code: String,
    name: String,
    date: Date,
    time: String,
    hall: String,
    seatNumber: String
  }],
  eligibilityStatus: {
    isEligible: { type: Boolean, default: false },
    reasons: [String] // ["Internal marks insufficient", "Fees not paid"]
  },
  feeStatus: {
    isPaid: { type: Boolean, default: false },
    amount: Number,
    paidDate: Date
  },
  internalEligibility: {
    isPassed: { type: Boolean, default: false },
    subjects: [{
      code: String,
      name: String,
      internalMarks: Number,
      requiredMarks: Number,
      isPassed: Boolean
    }]
  },
  generatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('HallTicket', hallTicketSchema);

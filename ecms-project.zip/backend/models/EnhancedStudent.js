const mongoose = require('mongoose');

const enhancedStudentSchema = new mongoose.Schema({
  studentId: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  email: String,
  phone: String,
  department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department' },
  program: String, // "B.Tech", "M.Tech"
  batch: String, // "2021-2025"
  regulation: String, // "R21"
  currentSemester: Number,
  admissionYear: Number,
  status: { 
    type: String, 
    enum: ['Active', 'Inactive', 'Graduated', 'Dropped'], 
    default: 'Active' 
  },
  feeStatus: [{
    semester: Number,
    academicYear: String,
    isPaid: { type: Boolean, default: false },
    paidDate: Date,
    amount: Number
  }],
  malpracticeRecords: [{
    examId: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam' },
    subject: String,
    date: Date,
    type: { type: String, enum: ['Copying', 'Impersonation', 'Unfair Means', 'Other'] },
    description: String,
    action: String,
    reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],
  cgpa: { type: Number, default: 0 },
  sgpa: [{ semester: Number, gpa: Number }]
}, { timestamps: true });

module.exports = mongoose.model('EnhancedStudent', enhancedStudentSchema);

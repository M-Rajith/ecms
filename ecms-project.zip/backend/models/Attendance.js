const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student' },
  exam: { type: mongoose.Schema.Types.ObjectId, ref: 'Exam' },
  present: { type: Boolean, default: false },
  seat: String
}, { timestamps: true });

module.exports = mongoose.model('Attendance', attendanceSchema);
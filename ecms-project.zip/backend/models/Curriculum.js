const mongoose = require('mongoose');

const curriculumSchema = new mongoose.Schema({
  department: { type: mongoose.Schema.Types.ObjectId, ref: 'Department', required: true },
  program: String, // "B.Tech", "M.Tech"
  batch: String, // "2021-2025"
  regulation: String, // "R21"
  subjects: [{
    code: String,
    name: String,
    semester: Number,
    credits: Number,
    type: { type: String, enum: ['Theory', 'Practical', 'Theory+Practical'] },
    internalMarks: Number,
    externalMarks: Number,
    totalMarks: Number,
    isElective: { type: Boolean, default: false }
  }],
  syllabus: [{
    subject: String,
    units: [{
      unitNumber: Number,
      topics: [String],
      outcomes: [String]
    }]
  }]
}, { timestamps: true });

module.exports = mongoose.model('Curriculum', curriculumSchema);

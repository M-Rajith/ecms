const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  text: String,
  subject: String,
  marks: Number,
  difficulty: { type: String, enum: ['Easy','Medium','Hard'], default: 'Medium' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });

module.exports = mongoose.model('Question', questionSchema);
const mongoose = require('mongoose');

const assessmentSchema = new mongoose.Schema({
  student: { type: mongoose.Schema.Types.ObjectId, ref: 'EnhancedStudent', required: true },
  subject: String,
  semester: Number,
  academicYear: String,
  assessmentType: { 
    type: String, 
    enum: ['Internal', 'External', 'Practical'], 
    required: true 
  },
  marks: {
    obtained: Number,
    total: Number,
    grade: String
  },
  components: [{
    name: String, // "Mid-1", "Mid-2", "Assignment", "Quiz"
    maxMarks: Number,
    obtainedMarks: Number,
    date: Date
  }],
  isFinalized: { type: Boolean, default: false },
  finalizedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  finalizedAt: Date,
  enteredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  lastModifiedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  examType: { 
    type: String, 
    enum: ['Regular', 'Supplementary', 'Arrear'], 
    default: 'Regular' 
  }
}, { timestamps: true });

module.exports = mongoose.model('Assessment', assessmentSchema);

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import ExamManagement from './components/ExamManagement';
import QuestionBank from './components/QuestionBank';
import Results from './components/Results';
import PaperGeneration from './components/PaperGeneration';
import AcademicManagement from './components/AcademicManagement';
import StudentManagement from './components/StudentManagement';
import ExamAttendance from './components/ExamAttendance';
import HallTicketEligibility from './components/HallTicketEligibility';
import EvaluationBundles from './components/EvaluationBundles';
import MyResults from './components/MyResults';
import HallTicketGeneration from './components/HallTicketGeneration';
import './App.css';
import Navbar from './components/Navbar';

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setUser(data);
        } else {
          localStorage.removeItem('token');
        }
      })
      .catch(() => localStorage.removeItem('token'))
      .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <Router>
      <div className="App">
        {user && <Navbar user={user} logout={logout} />}
        <Routes>
          <Route 
            path="/login" 
            element={!user ? <Login setUser={setUser} /> : <Navigate to="/dashboard" />} 
          />
          <Route 
            path="/dashboard" 
            element={user ? <Dashboard user={user} logout={logout} /> : <Navigate to="/login" />} 
          />
          <Route 
           path="/my-results" 
           element={user && user.role === "student" ? 
           <MyResults user={user} /> : <Navigate to="/login" />} 
           />
          <Route 
            path="/exams" 
            element={user ? <ExamManagement user={user} /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/questions" 
            element={user ? <QuestionBank user={user} /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/results" 
            element={user ? <Results user={user} /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/halltickets/generate" 
            element={(user && user.role === 'coordinator') ? 
            <HallTicketGeneration user={user} /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/papers" 
            element={user ? <PaperGeneration user={user} /> : <Navigate to="/login" />} 
          />
          <Route path="/academics" element={<AcademicManagement user={user} />} />
          <Route path="/students" element={<StudentManagement user={user} />} />
          <Route path="/attendance" element={<ExamAttendance user={user} />} />
          <Route path="/halltickets" element={<HallTicketEligibility user={user} />} />
          <Route path="/evaluation" element={<EvaluationBundles user={user} />} />
          <Route path="/" element={<Navigate to="/dashboard" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

import React, { useState, useEffect } from 'react';

const AcademicManagement = ({ user }) => {
  const [activeTab, setActiveTab] = useState('years');
  const [academicYears, setAcademicYears] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    fetchAcademicYears();
    fetchDepartments();
  }, []);

  const fetchAcademicYears = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/academics/years', {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setAcademicYears(data);
      }
    } catch (error) {
      console.error('Error fetching academic years:', error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/academics/departments', {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setDepartments(data);
      }
    } catch (error) {
      console.error('Error fetching departments:', error);
    }
  };

  const handleCreateAcademicYear = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/academics/years', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify(formData),
      });
      if (response.ok) {
        fetchAcademicYears();
        setShowCreateForm(false);
        setFormData({});
        alert('Academic year created successfully!');
      }
    } catch (error) {
      console.error('Error creating academic year:', error);
    }
  };

  if (!['coordinator', 'hod'].includes(user.role)) {
    return (
      <div className="access-denied">
        <h2>Access Denied</h2>
        <p>Only CoE and HoD can access academic management.</p>
      </div>
    );
  }

  return (
    <div className="academic-management">
      <h2>Academic Management</h2>

      <div className="tab-navigation">
        <button 
          className={activeTab === 'years' ? 'tab-active' : 'tab'}
          onClick={() => setActiveTab('years')}
        >
          Academic Years
        </button>
        <button 
          className={activeTab === 'departments' ? 'tab-active' : 'tab'}
          onClick={() => setActiveTab('departments')}
        >
          Departments
        </button>
        <button 
          className={activeTab === 'curriculum' ? 'tab-active' : 'tab'}
          onClick={() => setActiveTab('curriculum')}
        >
          Curriculum
        </button>
      </div>

      {activeTab === 'years' && (
        <div className="academic-years-section">
          <div className="section-header">
            <h3>Academic Years (2021 onwards)</h3>
            {user.role === 'coordinator' && (
              <button 
                className="primary-btn"
                onClick={() => setShowCreateForm(!showCreateForm)}
              >
                {showCreateForm ? 'Cancel' : 'Add Academic Year'}
              </button>
            )}
          </div>

          {showCreateForm && (
            <form onSubmit={handleCreateAcademicYear} className="create-form">
              <h4>Create Academic Year</h4>
              <div className="form-row">
                <div className="form-group">
                  <label>Academic Year:</label>
                  <input
                    type="text"
                    placeholder="e.g., 2024-2025"
                    value={formData.year || ''}
                    onChange={(e) => setFormData({...formData, year: e.target.value})}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Start Date:</label>
                  <input
                    type="date"
                    value={formData.startDate || ''}
                    onChange={(e) => setFormData({...formData, startDate: e.target.value})}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>End Date:</label>
                  <input
                    type="date"
                    value={formData.endDate || ''}
                    onChange={(e) => setFormData({...formData, endDate: e.target.value})}
                    required
                  />
                </div>
              </div>
              <button type="submit" className="submit-btn">
                Create Academic Year
              </button>
            </form>
          )}

          <div className="data-grid">
            {academicYears.map(year => (
              <div key={year._id} className="data-card">
                <div className="card-header">
                  <h4>{year.year}</h4>
                  {year.isActive && <span className="status-badge active">Active</span>}
                </div>
                <p><strong>Duration:</strong> {new Date(year.startDate).toLocaleDateString()} - {new Date(year.endDate).toLocaleDateString()}</p>
                <p><strong>Semesters:</strong> {year.semesters?.length || 0}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'departments' && (
        <div className="departments-section">
          <h3>Departments & Programs</h3>
          <div className="data-grid">
            {departments.map(dept => (
              <div key={dept._id} className="data-card">
                <div className="card-header">
                  <h4>{dept.name}</h4>
                  <span className="dept-code">{dept.code}</span>
                </div>
                <p><strong>HoD:</strong> {dept.hod?.name || 'Not Assigned'}</p>
                <div className="programs">
                  <strong>Programs:</strong>
                  {dept.programs?.map((program, index) => (
                    <span key={index} className="program-tag">
                      {program.name} ({program.duration}Y)
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'curriculum' && (
        <div className="curriculum-section">
          <h3>Curriculum Management</h3>
          <p>Curriculum management interface will be displayed here.</p>
          <div className="curriculum-info">
            <div className="info-card">
              <h4>OBE Support</h4>
              <p>Outcome-Based Education features integrated</p>
            </div>
            <div className="info-card">
              <h4>Regulation Management</h4>
              <p>Support for different batch regulations (R21, R18, etc.)</p>
            </div>
            <div className="info-card">
              <h4>Syllabus Archive</h4>
              <p>Complete syllabus storage from 2021 onwards</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AcademicManagement;

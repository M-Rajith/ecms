import React, { useState, useEffect } from 'react';

const QuestionBank = ({ user }) => {
  const [questions, setQuestions] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    text: '', subject: '', marks: '', difficulty: 'Medium'
  });

  useEffect(() => {
    fetchQuestions();
  }, []);

  const fetchQuestions = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/questionbank', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setQuestions(data);
      }
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  const handleCreateQuestion = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/questionbank', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newQuestion)
      });

      if (response.ok) {
        fetchQuestions();
        setShowCreateForm(false);
        setNewQuestion({ text: '', subject: '', marks: '', difficulty: 'Medium' });
        alert('Question created successfully!');
      } else {
        const error = await response.json();
        alert('Error: ' + error.error);
      }
    } catch (error) {
      console.error('Error creating question:', error);
    }
  };

  if (user.role === 'student') {
    return (
      <div className="access-denied">
        <h2>Access Denied</h2>
        <p>Students cannot access the Question Bank.</p>
      </div>
    );
  }

  return (
    <div className="question-bank">
      <h2>Question Bank Management</h2>

      {(user.role === 'coordinator' || user.role === 'faculty') && (
        <div className="create-question-section">
          <button 
            className="primary-btn"
            onClick={() => setShowCreateForm(!showCreateForm)}
          >
            {showCreateForm ? 'Cancel' : 'Add New Question'}
          </button>

          {showCreateForm && (
            <form onSubmit={handleCreateQuestion} className="create-form">
              <h3>Create New Question</h3>
              <div className="form-group">
                <label>Question Text:</label>
                <textarea
                  value={newQuestion.text}
                  onChange={(e) => setNewQuestion({...newQuestion, text: e.target.value})}
                  required
                  rows="3"
                  placeholder="Enter your question here..."
                />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Subject:</label>
                  <input
                    type="text"
                    value={newQuestion.subject}
                    onChange={(e) => setNewQuestion({...newQuestion, subject: e.target.value})}
                    required
                    placeholder="e.g., Operating Systems"
                  />
                </div>
                <div className="form-group">
                  <label>Marks:</label>
                  <input
                    type="number"
                    value={newQuestion.marks}
                    onChange={(e) => setNewQuestion({...newQuestion, marks: e.target.value})}
                    required
                    min="1"
                  />
                </div>
                <div className="form-group">
                  <label>Difficulty:</label>
                  <select
                    value={newQuestion.difficulty}
                    onChange={(e) => setNewQuestion({...newQuestion, difficulty: e.target.value})}
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                  </select>
                </div>
              </div>
              <button type="submit" className="submit-btn">Create Question</button>
            </form>
          )}
        </div>
      )}

      <div className="questions-list">
        <h3>All Questions ({questions.length})</h3>
        {questions.length > 0 ? (
          <div className="questions-grid">
            {questions.map(question => (
              <div key={question._id} className="question-card">
                <div className="question-header">
                  <span className="subject-tag">{question.subject}</span>
                  <span className={`difficulty-tag ${question.difficulty.toLowerCase()}`}>
                    {question.difficulty}
                  </span>
                </div>
                <p className="question-text">{question.text}</p>
                <div className="question-footer">
                  <span className="marks-info">{question.marks} marks</span>
                  <span className="created-by">
                    By: {question.createdBy?.name || 'Unknown'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-data">No questions found. Create some questions to get started.</p>
        )}
      </div>
    </div>
  );
};

export default QuestionBank;

import React, { useState, useEffect } from 'react';

const PaperGeneration = ({ user }) => {
  const [exams, setExams] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [paperForm, setPaperForm] = useState({
    examId: '',
    numQuestions: 10,
    subject: ''
  });
  const [generatedPaper, setGeneratedPaper] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchExams();
    fetchSubjects();
  }, []);

  const fetchExams = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/exams', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setExams(data);
      }
    } catch (error) {
      console.error('Error fetching exams:', error);
    }
  };

  const fetchSubjects = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/questionbank', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        // Extract unique subjects from questions
        const uniqueSubjects = [...new Set(data.map(q => q.subject))];
        setSubjects(uniqueSubjects);
      }
    } catch (error) {
      console.error('Error fetching subjects:', error);
    }
  };

  const generatePaper = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/papers/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(paperForm)
      });

      if (response.ok) {
        const data = await response.json();
        setGeneratedPaper(data);
        alert('Exam paper generated successfully!');
      } else {
        const error = await response.json();
        alert('Error: ' + error.error);
      }
    } catch (error) {
      console.error('Error generating paper:', error);
      alert('Failed to generate paper. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const printPaper = () => {
    const printWindow = window.open('', '_blank');
    const selectedExam = exams.find(e => e._id === paperForm.examId);
    
    const printContent = `
      <html>
        <head>
          <title>Exam Paper - ${selectedExam?.title || 'Unknown Exam'}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
            .question { margin-bottom: 20px; padding: 15px; border-left: 4px solid #007bff; }
            .question-number { font-weight: bold; color: #007bff; }
            .marks { float: right; font-weight: bold; }
            .instructions { background: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 30px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${selectedExam?.title || 'Exam Paper'}</h1>
            <h3>Course: ${selectedExam?.course || 'N/A'}</h3>
            <p><strong>Code:</strong> ${selectedExam?.code || 'N/A'} | <strong>Date:</strong> ${selectedExam ? new Date(selectedExam.date).toLocaleDateString() : 'N/A'}</p>
            <p><strong>Time:</strong> ${selectedExam?.startTime || 'N/A'} to ${selectedExam?.endTime || 'N/A'} | <strong>Total Marks:</strong> ${generatedPaper.totalMarks}</p>
          </div>
          
          <div class="instructions">
            <h4>Instructions:</h4>
            <ul>
              <li>Answer all questions</li>
              <li>Write clearly and legibly</li>
              <li>Marks for each question are indicated</li>
              <li>Manage your time effectively</li>
            </ul>
          </div>

          ${generatedPaper.questions.map((question, index) => `
            <div class="question">
              <span class="marks">[${question.marks} marks]</span>
              <div class="question-number">Q${index + 1}.</div>
              <div>${question.text}</div>
              <br><br><br>
            </div>
          `).join('')}
        </body>
      </html>
    `;
    
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  if (user.role !== 'coordinator') {
    return (
      <div className="access-denied">
        <h2>Access Denied</h2>
        <p>Only coordinators can generate exam papers.</p>
      </div>
    );
  }

  return (
    <div className="paper-generation">
      <h2>Exam Paper Generation</h2>

      <div className="generate-paper-section">
        <form onSubmit={generatePaper} className="create-form">
          <h3>Generate New Exam Paper</h3>
          
          <div className="form-group">
            <label>Select Exam:</label>
            <select
              value={paperForm.examId}
              onChange={(e) => setPaperForm({...paperForm, examId: e.target.value})}
              required
            >
              <option value="">-- Select an Exam --</option>
              {exams.map(exam => (
                <option key={exam._id} value={exam._id}>
                  {exam.title} - {exam.code} ({new Date(exam.date).toLocaleDateString()})
                </option>
              ))}
            </select>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Number of Questions:</label>
              <input
                type="number"
                value={paperForm.numQuestions}
                onChange={(e) => setPaperForm({...paperForm, numQuestions: e.target.value})}
                min="1"
                max="50"
                required
              />
            </div>
            
            <div className="form-group">
              <label>Subject Filter (Optional):</label>
              <select
                value={paperForm.subject}
                onChange={(e) => setPaperForm({...paperForm, subject: e.target.value})}
              >
                <option value="">-- All Subjects --</option>
                {subjects.map(subject => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>
          </div>

          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? 'Generating Paper...' : 'Generate Paper'}
          </button>
        </form>
      </div>

      {generatedPaper && (
        <div className="generated-paper-display">
          <div className="paper-header">
            <h3>Generated Paper Preview</h3>
            <div className="paper-actions">
              <button onClick={printPaper} className="primary-btn">
                Print Paper
              </button>
              <button 
                onClick={() => setGeneratedPaper(null)} 
                className="secondary-btn"
              >
                Generate New Paper
              </button>
            </div>
          </div>

          <div className="paper-info">
            <div className="info-grid">
              <div className="info-card">
                <h4>Total Questions</h4>
                <span>{generatedPaper.questions.length}</span>
              </div>
              <div className="info-card">
                <h4>Total Marks</h4>
                <span>{generatedPaper.totalMarks}</span>
              </div>
              <div className="info-card">
                <h4>Subjects Covered</h4>
                <span>{[...new Set(generatedPaper.questions.map(q => q.subject))].length}</span>
              </div>
            </div>
          </div>

          <div className="questions-preview">
            <h4>Questions Preview:</h4>
            {generatedPaper.questions.map((question, index) => (
              <div key={question._id} className="preview-question">
                <div className="question-header">
                  <span className="question-number">Q{index + 1}</span>
                  <span className="question-marks">{question.marks} marks</span>
                  <span className="question-subject">{question.subject}</span>
                  <span className={`difficulty-tag ${question.difficulty.toLowerCase()}`}>
                    {question.difficulty}
                  </span>
                </div>
                <div className="question-text">{question.text}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default PaperGeneration;

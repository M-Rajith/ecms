import React, { useState } from 'react';

const HallTicketGeneration = ({ user }) => {
  const [studentId, setStudentId] = useState('');
  const [semester, setSemester] = useState('');
  const [academicYear, setAcademicYear] = useState('');
  const [hallTicket, setHallTicket] = useState(null);
  const [error, setError] = useState(null);

  const generateHallTicket = async (e) => {
    e.preventDefault();
    setError(null);
    setHallTicket(null);

    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/halltickets/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
        body: JSON.stringify({ studentId, semester, academicYear }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to generate hall ticket');
      }

      const data = await res.json();
      setHallTicket(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="hall-ticket-gen">
      <h2>Generate Hall Ticket</h2>
      <form onSubmit={generateHallTicket}>
        <div className="form-group">
          <label>Student ID:</label>
          <input 
            type="text" value={studentId} required
            onChange={(e) => setStudentId(e.target.value)} 
          />
        </div>
        <div className="form-group">
          <label>Semester:</label>
          <input 
            type="number" value={semester} min="1" required
            onChange={(e) => setSemester(e.target.value)} 
          />
        </div>
        <div className="form-group">
          <label>Academic Year:</label>
          <input 
            type="text" value={academicYear} placeholder="e.g., 2024-2025" required
            onChange={(e) => setAcademicYear(e.target.value)} 
          />
        </div>
        <button type="submit" className="primary-btn">Generate Hall Ticket</button>
      </form>

      {error && <p style={{color:'red'}}>{error}</p>}

      {hallTicket && (
        <div className="hall-ticket-details">
          <h3>Hall Ticket Generated Successfully</h3>
          <p><strong>Ticket Number:</strong> {hallTicket.ticketNumber}</p>
          <p><strong>Student ID:</strong> {studentId}</p>
          <p><strong>Semester:</strong> {hallTicket.semester}</p>
          <p><strong>Academic Year:</strong> {hallTicket.academicYear}</p>
          {/* Add more details or download/print button here */}
        </div>
      )}
    </div>
  );
};

export default HallTicketGeneration;

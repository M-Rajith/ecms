import React, { useState, useEffect } from 'react';

const ExamAttendance = ({ user }) => {
  const [exams, setExams] = useState([]);
  const [selectedExam, setSelectedExam] = useState('');
  const [attendanceList, setAttendanceList] = useState([]);

  useEffect(() => {
    fetch('/api/exams', {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    })
      .then(res => res.json()).then(setExams);
  }, []);

  useEffect(() => {
    if (selectedExam)
      fetch(`/api/attendance/exam/${selectedExam}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      })
        .then(res => res.json()).then(setAttendanceList);
  }, [selectedExam]);

  const markAttendance = async (attendanceId, status) => {
    await fetch(`/api/attendance/${attendanceId}/finalize`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setAttendanceList(lst =>
      lst.map(a => (a._id === attendanceId ? { ...a, attendanceStatus: status, isFinalized: true } : a))
    );
  };

  return (
    <div className="exam-attendance">
      <h2>Examination Attendance</h2>
      <select onChange={e => setSelectedExam(e.target.value)} value={selectedExam}>
        <option value="">Select Exam</option>
        {exams.map(exam => (
          <option key={exam._id} value={exam._id}>{exam.title}</option>
        ))}
      </select>
      {selectedExam && (
        <table className="results-table">
          <thead>
            <tr>
              <th>Student</th>
              <th>Status</th>
              <th>Action</th>
              <th>Finalize</th>
            </tr>
          </thead>
          <tbody>
            {attendanceList.map(att => (
              <tr key={att._id}>
                <td>{att.student?.name} ({att.student?.studentId})</td>
                <td>{att.attendanceStatus}</td>
                <td>
                  {!att.isFinalized && (
                    <>
                      <button onClick={() => markAttendance(att._id, "Present")}>Mark Present</button>
                      <button onClick={() => markAttendance(att._id, "Absent")}>Mark Absent</button>
                      <button onClick={() => markAttendance(att._id, "Malpractice")}>Malpractice</button>
                    </>
                  )}
                </td>
                <td>{att.isFinalized ? "Finalized" : "Not Finalized"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};
export default ExamAttendance;

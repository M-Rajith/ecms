import React, { useState, useEffect } from 'react';

const EvaluationBundles = ({ user }) => {
  const [examId, setExamId] = useState('');
  const [bundles, setBundles] = useState([]);

  const fetchBundles = async () => {
    const res = await fetch(`/api/evaluation/summary/${examId}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setBundles(await res.json());
  };

  return (
    <div>
      <h2>Evaluation Bundle Summary</h2>
      <input value={examId} onChange={e => setExamId(e.target.value)} placeholder="Exam ID" />
      <button onClick={fetchBundles}>Get Bundles</button>
      <div>
        {bundles.map(bundle => (
          <div key={bundle.bundleNumber}>
            <h3>Bundle {bundle.bundleNumber} ({bundle.subject})</h3>
            <table>
              <thead>
                <tr>
                  <th>Student ID</th><th>Status</th><th>Evaluated</th>
                </tr>
              </thead>
              <tbody>
                {bundle.scripts.map((script, idx) => (
                  <tr key={idx}>
                    <td>{script.student}</td>
                    <td>{script.status}</td>
                    <td>{script.isEvaluated ? "Done" : "Pending"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ))}
      </div>
    </div>
  );
};
export default EvaluationBundles;

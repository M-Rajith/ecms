import React, { useState, useEffect } from 'react';

const Results = ({ user }) => {
  const [exams, setExams] = useState([]);
  const [selectedExam, setSelectedExam] = useState('');
  const [results, setResults] = useState(null);
  const [showMarkEntry, setShowMarkEntry] = useState(false);
  const [markEntry, setMarkEntry] = useState({
    studentId: '', marks: '', totalMarks: 100
  });

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/exams', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setExams(data);
      }
    } catch (error) {
      console.error('Error fetching exams:', error);
    }
  };

  const fetchResults = async (examId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/marks/exam/${examId}/results`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setResults(data);
      }
    } catch (error) {
      console.error('Error fetching results:', error);
    }
  };

  const handleEnterMarks = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/marks/enter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          examId: selectedExam,
          ...markEntry
        })
      });

      if (response.ok) {
        alert('Marks entered successfully!');
        setMarkEntry({ studentId: '', marks: '', totalMarks: 100 });
        setShowMarkEntry(false);
        if (selectedExam) {
          fetchResults(selectedExam);
        }
      } else {
        const error = await response.json();
        alert('Error: ' + error.error);
      }
    } catch (error) {
      console.error('Error entering marks:', error);
    }
  };

  return (
    <div className="results-management">
      <h2>Results Management</h2>

      <div className="exam-selector">
        <label>Select Exam to View Results:</label>
        <select
          value={selectedExam}
          onChange={(e) => {
            setSelectedExam(e.target.value);
            if (e.target.value) {
              fetchResults(e.target.value);
            } else {
              setResults(null);
            }
          }}
        >
          <option value="">-- Select an Exam --</option>
          {exams.map(exam => (
            <option key={exam._id} value={exam._id}>
              {exam.title} - {exam.code} ({new Date(exam.date).toLocaleDateString()})
            </option>
          ))}
        </select>
      </div>

      {selectedExam && (user.role === 'coordinator' || user.role === 'faculty') && (
        <div className="marks-entry-section">
          <button 
            className="primary-btn"
            onClick={() => setShowMarkEntry(!showMarkEntry)}
          >
            {showMarkEntry ? 'Cancel' : 'Enter Marks'}
          </button>

          {showMarkEntry && (
            <form onSubmit={handleEnterMarks} className="create-form">
              <h3>Enter Student Marks</h3>
              <div className="form-row">
                <div className="form-group">
                  <label>Student ID:</label>
                  <input
                    type="text"
                    value={markEntry.studentId}
                    onChange={(e) => setMarkEntry({...markEntry, studentId: e.target.value})}
                    placeholder="e.g., S1001"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Marks Obtained:</label>
                  <input
                    type="number"
                    value={markEntry.marks}
                    onChange={(e) => setMarkEntry({...markEntry, marks: e.target.value})}
                    required
                    min="0"
                  />
                </div>
                <div className="form-group">
                  <label>Total Marks:</label>
                  <input
                    type="number"
                    value={markEntry.totalMarks}
                    onChange={(e) => setMarkEntry({...markEntry, totalMarks: e.target.value})}
                    required
                    min="1"
                  />
                </div>
              </div>
              <button type="submit" className="submit-btn">Enter Marks</button>
            </form>
          )}
        </div>
      )}

      {results && (
        <div className="results-display">
          <h3>Exam Results</h3>
          
          <div className="stats-summary">
            <div className="stat-card">
              <h4>Total Students</h4>
              <span className="stat-number">{results.stats.totalStudents}</span>
            </div>
            <div className="stat-card">
              <h4>Average Marks</h4>
              <span className="stat-number">{results.stats.averageMarks.toFixed(2)}</span>
            </div>
            <div className="stat-card">
              <h4>Highest Score</h4>
              <span className="stat-number">{results.stats.highestMarks}</span>
            </div>
            <div className="stat-card">
              <h4>Students Passed</h4>
              <span className="stat-number">{results.stats.passedStudents}</span>
            </div>
          </div>

          {results.marks.length > 0 ? (
            <div className="results-table">
              <table>
                <thead>
                  <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Marks Obtained</th>
                    <th>Total Marks</th>
                    <th>Grade</th>
                    <th>Percentage</th>
                  </tr>
                </thead>
                <tbody>
                  {results.marks.map(mark => (
                    <tr key={mark._id}>
                      <td>{mark.student.studentId}</td>
                      <td>{mark.student.name}</td>
                      <td>{mark.student.department}</td>
                      <td>{mark.marks}</td>
                      <td>{mark.totalMarks}</td>
                      <td className={`grade-${mark.grade}`}>{mark.grade}</td>
                      <td>{((mark.marks / mark.totalMarks) * 100).toFixed(1)}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="no-data">No results found for this exam.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default Results;

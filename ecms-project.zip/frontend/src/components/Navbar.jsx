import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = ({ user, logout }) => {
  return (
    <header className="app-navbar">
      <div className="brand">
        <Link to="/dashboard">ECMS</Link>
      </div>

      <nav className="nav-links">
        <Link to="/dashboard">Dashboard</Link>
        {user && ['coordinator','hod','faculty','admin'].includes(user.role) && <Link to="/exams">Exams</Link>}
        {user && (user.role === 'student') && <Link to="/my-results">My Results</Link>}
        <Link to="/questions">Question Bank</Link>
      </nav>

      <div className="nav-actions">
        <span className="user-name">Hi, {user?.name || 'User'}</span>
        <button className="logout-btn" onClick={logout}>Logout</button>
      </div>
    </header>
  );
};

export default Navbar;

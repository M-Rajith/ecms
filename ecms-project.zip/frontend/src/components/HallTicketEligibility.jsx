import React, { useState } from 'react';

const HallTicketEligibility = () => {
  const [studentId, setStudentId] = useState('');
  const [semester, setSemester] = useState('');
  const [eligible, setEligible] = useState(null);

  const checkEligibility = async () => {
    const res = await fetch(`/api/halltickets/eligibility/${studentId}/${semester}`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
    });
    setEligible(await res.json());
  };

  return (
    <div>
      <h2>Hall Ticket Eligibility Check</h2>
      <input placeholder="Student ID" value={studentId} onChange={e => setStudentId(e.target.value)} />
      <input placeholder="Semester" value={semester} onChange={e => setSemester(e.target.value)} />
      <button onClick={checkEligibility}>Check</button>
      {eligible && (
        <div>
          <h3>{eligible.isEligible ? "Eligible" : "Not Eligible"}</h3>
          <ul>
            {eligible.reasons && eligible.reasons.map(r => <li key={r}>{r}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
};
export default HallTicketEligibility;

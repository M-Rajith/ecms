import React, { useEffect, useState } from 'react';

const MyResults = ({ user }) => {
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (user && user.studentId) {
      fetchResults(user.studentId);
    }
  }, [user]);

  const fetchResults = async (studentId) => {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/students/${studentId}/profile`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error("Failed to fetch results");
      const data = await res.json();
      setResults(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading your results...</div>;
  if (error) return <div>Error loading results: {error}</div>;

  if (!results)
    return <div>No results found for your profile. Please contact administration.</div>;

  const { student, semesterResults } = results;

  return (
    <div className="my-results">
      <h2>My Results</h2>
      <p><strong>Name:</strong> {student.name}</p>
      <p><strong>Student ID:</strong> {student.studentId}</p>
      <p><strong>Department:</strong> {student.department?.name}</p>
      <p><strong>Program:</strong> {student.program}</p>
      <p><strong>Batch:</strong> {student.batch}</p>

      {semesterResults.length === 0 && <p>No semester results available yet.</p>}

      {semesterResults.map((semester, idx) => (
        <div key={idx} className="semester-result">
          <h3>Semester {semester.semester} - {semester.academicYear}</h3>
          <table className="results-table">
            <thead>
              <tr>
                <th>Subject</th>
                <th>Internal Marks</th>
                <th>External Marks</th>
                <th>Practical Marks</th>
                <th>Grade</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {Object.values(semester.subjects).map((sub, subIdx) => (
                <tr key={subIdx}>
                  <td>{sub.subject}</td>
                  <td>{sub.internal ? `${sub.internal.obtained} / ${sub.internal.total}` : 'N/A'}</td>
                  <td>{sub.external ? `${sub.external.obtained} / ${sub.external.total}` : 'N/A'}</td>
                  <td>{sub.practical ? `${sub.practical.obtained} / ${sub.practical.total}` : 'N/A'}</td>
                  <td>{sub.grade || 'Pending'}</td>
                  <td>{sub.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ))}
    </div>
  );
};

export default MyResults;

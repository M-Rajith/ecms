import React, { useState, useEffect } from 'react';

const StudentManagement = ({ user }) => {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [studentProfile, setStudentProfile] = useState(null);
  const [filters, setFilters] = useState({
    department: '',
    batch: '',
    semester: '',
    status: 'Active'
  });
  const [showMalpracticeForm, setShowMalpracticeForm] = useState(false);
  const [malpracticeData, setMalpracticeData] = useState({});

  useEffect(() => {
    fetchStudents();
  }, [filters]);

  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem('token');
      const queryParams = new URLSearchParams(filters).toString();
      const response = await fetch(`/api/students?${queryParams}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStudents(data);
      }
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const fetchStudentProfile = async (studentId) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/students/${studentId}/profile`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStudentProfile(data);
      }
    } catch (error) {
      console.error('Error fetching student profile:', error);
    }
  };

  const handleAddMalpractice = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/students/${selectedStudent.studentId}/malpractice`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(malpracticeData)
      });

      if (response.ok) {
        alert('Malpractice record added successfully');
        setShowMalpracticeForm(false);
        setMalpracticeData({});
        if (selectedStudent) {
          fetchStudentProfile(selectedStudent.studentId);
        }
      }
    } catch (error) {
      console.error('Error adding malpractice record:', error);
    }
  };

  return (
    <div className="student-management">
      <h2>Student Data Management</h2>

      <div className="filters-section">
        <h3>Filter Students</h3>
        <div className="form-row">
          <div className="form-group">
            <label>Department:</label>
            <select
              value={filters.department}
              onChange={(e) => setFilters({...filters, department: e.target.value})}
            >
              <option value="">All Departments</option>
              <option value="CSE">Computer Science</option>
              <option value="ECE">Electronics</option>
              <option value="ME">Mechanical</option>
              <option value="CE">Civil</option>
            </select>
          </div>
          <div className="form-group">
            <label>Batch:</label>
            <select
              value={filters.batch}
              onChange={(e) => setFilters({...filters, batch: e.target.value})}
            >
              <option value="">All Batches</option>
              <option value="2021-2025">2021-2025</option>
              <option value="2022-2026">2022-2026</option>
              <option value="2023-2027">2023-2027</option>
              <option value="2024-2028">2024-2028</option>
            </select>
          </div>
          <div className="form-group">
            <label>Status:</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters({...filters, status: e.target.value})}
            >
              <option value="">All Status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Graduated">Graduated</option>
              <option value="Dropped">Dropped</option>
            </select>
          </div>
        </div>
      </div>

      <div className="students-grid">
        <div className="students-list">
          <h3>Students ({students.length})</h3>
          {students.map(student => (
            <div 
              key={student._id} 
              className={`student-card ${selectedStudent?._id === student._id ? 'selected' : ''}`}
              onClick={() => {
                setSelectedStudent(student);
                fetchStudentProfile(student.studentId);
              }}
            >
              <div className="student-info">
                <h4>{student.name}</h4>
                <p><strong>ID:</strong> {student.studentId}</p>
                <p><strong>Batch:</strong> {student.batch}</p>
                <p><strong>Dept:</strong> {student.department?.code}</p>
                <p><strong>Semester:</strong> {student.currentSemester}</p>
              </div>
              <div className="student-status">
                <span className={`status-badge ${student.status.toLowerCase()}`}>
                  {student.status}
                </span>
                {student.malpracticeRecords?.length > 0 && (
                  <span className="malpractice-indicator">
                    ⚠️ {student.malpracticeRecords.length}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {studentProfile && (
          <div className="student-profile">
            <div className="profile-header">
              <h3>{studentProfile.student.name}'s Profile</h3>
              {(user.role === 'coordinator' || user.role === 'faculty') && (
                <button 
                  className="warning-btn"
                  onClick={() => setShowMalpracticeForm(true)}
                >
                  Report Malpractice
                </button>
              )}
            </div>

            <div className="profile-sections">
              <div className="profile-card">
                <h4>Personal Information</h4>
                <div className="info-grid">
                  <div><strong>Student ID:</strong> {studentProfile.student.studentId}</div>
                  <div><strong>Email:</strong> {studentProfile.student.email}</div>
                  <div><strong>Phone:</strong> {studentProfile.student.phone}</div>
                  <div><strong>Department:</strong> {studentProfile.student.department?.name}</div>
                  <div><strong>Program:</strong> {studentProfile.student.program}</div>
                  <div><strong>Batch:</strong> {studentProfile.student.batch}</div>
                  <div><strong>Current CGPA:</strong> {studentProfile.student.cgpa.toFixed(2)}</div>
                  <div><strong>Status:</strong> 
                    <span className={`status-badge ${studentProfile.student.status.toLowerCase()}`}>
                      {studentProfile.student.status}
                    </span>
                  </div>
                </div>
              </div>

              <div className="profile-card">
                <h4>Academic History</h4>
                {studentProfile.semesterResults.map((semester, index) => (
                  <div key={index} className="semester-result">
                    <h5>Semester {semester.semester} - {semester.academicYear}</h5>
                    <div className="subjects-grid">
                      {Object.values(semester.subjects).map((subject, subIndex) => (
                        <div key={subIndex} className="subject-result">
                          <strong>{subject.subject}</strong>
                          <div className="marks">
                            Internal: {subject.internal?.obtained || 'N/A'}/{subject.internal?.total || 'N/A'}
                          </div>
                          <div className="marks">
                            External: {subject.external?.obtained || 'N/A'}/{subject.external?.total || 'N/A'}
                          </div>
                          <div className="grade">Grade: {subject.grade || 'Pending'}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {studentProfile.student.malpracticeRecords.length > 0 && (
                <div className="profile-card malpractice-section">
                  <h4>Malpractice Records ({studentProfile.student.malpracticeRecords.length})</h4>
                  {studentProfile.student.malpracticeRecords.map((record, index) => (
                    <div key={index} className="malpractice-record">
                      <div className="record-header">
                        <strong>{record.type}</strong>
                        <span className="date">{new Date(record.date).toLocaleDateString()}</span>
                      </div>
                      <p><strong>Subject:</strong> {record.subject}</p>
                      <p><strong>Description:</strong> {record.description}</p>
                      <p><strong>Action:</strong> {record.action}</p>
                    </div>
                  ))}
                </div>
              )}

              <div className="profile-card">
                <h4>Fee Status</h4>
                {studentProfile.student.feeStatus.map((fee, index) => (
                  <div key={index} className="fee-record">
                    <div className="fee-info">
                      <strong>Semester {fee.semester} - {fee.academicYear}</strong>
                      <span className={`fee-status ${fee.isPaid ? 'paid' : 'pending'}`}>
                        {fee.isPaid ? 'Paid' : 'Pending'}
                      </span>
                    </div>
                    <div className="fee-details">
                      <span>Amount: ₹{fee.amount}</span>
                      {fee.isPaid && (
                        <span>Paid on: {new Date(fee.paidDate).toLocaleDateString()}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {showMalpracticeForm && (
        <div className="modal-overlay">
          <div className="modal">
            <form onSubmit={handleAddMalpractice} className="malpractice-form">
              <h3>Report Malpractice - {selectedStudent?.name}</h3>
              <div className="form-group">
                <label>Type:</label>
                <select
                  value={malpracticeData.type || ''}
                  onChange={(e) => setMalpracticeData({...malpracticeData, type: e.target.value})}
                  required
                >
                  <option value="">Select Type</option>
                  <option value="Copying">Copying</option>
                  <option value="Impersonation">Impersonation</option>
                  <option value="Unfair Means">Unfair Means</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="form-group">
                <label>Subject:</label>
                <input
                  type="text"
                  value={malpracticeData.subject || ''}
                  onChange={(e) => setMalpracticeData({...malpracticeData, subject: e.target.value})}
                  required
                />
              </div>
              <div className="form-group">
                <label>Description:</label>
                <textarea
                  value={malpracticeData.description || ''}
                  onChange={(e) => setMalpracticeData({...malpracticeData, description: e.target.value})}
                  rows="3"
                  required
                />
              </div>
              <div className="form-group">
                <label>Action Taken:</label>
                <textarea
                  value={malpracticeData.action || ''}
                  onChange={(e) => setMalpracticeData({...malpracticeData, action: e.target.value})}
                  rows="2"
                />
              </div>
              <div className="form-actions">
                <button type="submit" className="submit-btn">Report Malpractice</button>
                <button 
                  type="button" 
                  className="secondary-btn"
                  onClick={() => setShowMalpracticeForm(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentManagement;

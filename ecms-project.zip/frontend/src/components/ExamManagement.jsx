import React, { useState, useEffect } from 'react';

const ExamManagement = ({ user }) => {
  const [exams, setExams] = useState([]);

  useEffect(() => {
    fetchExams();
  }, []);

  const fetchExams = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/exams', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (response.ok) {
        const data = await response.json();
        setExams(data);
      }
    } catch (error) {
      console.error('Error fetching exams:', error);
    }
  };

  return (
    <div className="exam-management">
      <h2>Exam Management</h2>
      
      <div className="exams-list">
        <h3>All Exams</h3>
        {exams.length > 0 ? (
          <div className="exams-grid">
            {exams.map(exam => (
              <div key={exam._id} className="exam-card">
                <h4>{exam.title}</h4>
                <p><strong>Code:</strong> {exam.code}</p>
                <p><strong>Course:</strong> {exam.course}</p>
                <p><strong>Date:</strong> {new Date(exam.date).toLocaleDateString()}</p>
                <p><strong>Time:</strong> {exam.startTime} - {exam.endTime}</p>
              </div>
            ))}
          </div>
        ) : (
          <p>No exams found</p>
        )}
      </div>
    </div>
  );
};

export default ExamManagement;

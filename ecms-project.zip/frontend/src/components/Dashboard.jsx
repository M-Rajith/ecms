import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = ({ user, logout }) => {
  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>ECMS Dashboard</h1>
        <div className="user-info">
          <span>Welcome, {user.name} ({user.role})</span>
          <button onClick={logout} className="logout-btn">Logout</button>
        </div>
      </header>

      <nav className="dashboard-nav">
        {['coordinator', 'hod', 'faculty'].includes(user.role) && (
          <>
            <Link to="/exams" className="nav-item">Exam Management</Link>
            <Link to="/questions" className="nav-item">Question Bank</Link>
            <Link to="/results" className="nav-item">Results</Link>
            <Link to="/academics" className="nav-item">Academics</Link>
            <Link to="/students" className="nav-item">Students</Link>
            <Link to="/attendance" className="nav-item">Exam Attendance</Link>
            <Link to="/evaluation" className="nav-item">Evaluation Bundles</Link>
            <Link to="/papers" className="nav-item">Generate Papers</Link>
            <Link to="/halltickets" className="nav-item">Hall Tickets</Link>
            <Link to="/halltickets/generate" className="nav-item">Generate Hall Tickets</Link>
          </>
        )}

        {user.role === 'student' && (
          <>
            <Link to="/my-results" className="nav-item">My Results</Link>
            <Link to="/halltickets" className="nav-item">Hall Tickets</Link>
            <Link to="/exams" className="nav-item">Exam Management</Link>
          </>
        )}
      </nav>

      {/* You can add more dashboard overview widgets here */}

    </div>
  );
};

export default Dashboard;

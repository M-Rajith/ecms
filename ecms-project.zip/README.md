# ECMS - Examination Content Management System

## Complete Full-Stack Project

### Quick Start

1. **Backend Setup:**
   ```bash
   cd backend
   npm install
   npm run seed
   npm run dev
   ```

2. **Frontend Setup:**
   ```bash
   cd frontend  
   npm install
   npm run dev
   ```

3. **Default Login:**
   - Coordinator: coe@example.com / password
   - Faculty: faculty@example.com / password
   - Student: student@example.com / password

### Features
- JWT Authentication
- Role-based Access Control
- Exam Management
- Question Bank
- Seating Arrangement
- Hall Ticket Generation
- Results Management
- Analytics Dashboard

### Tech Stack
- **Backend:** Node.js, Express.js, MongoDB, JWT
- **Frontend:** React 18, Vite, React Router
- **Database:** MongoDB with Mongoose ODM

### API Endpoints
- POST /api/auth/login - User login
- GET /api/exams - Get all exams
- POST /api/exams - Create exam (coordinator only)
- GET /api/analytics/dashboard - Dashboard stats

### Project Structure
```
ecms-project/
├── backend/         # Node.js API server
│   ├── models/      # Database models
│   ├── routes/      # API routes
│   └── uploads/     # File uploads
└── frontend/        # React application
    └── src/         # React components
```

For detailed setup instructions, see the documentation files.